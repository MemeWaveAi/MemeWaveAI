export const LUMA_CONSTANTS = {
    API_URL: "https://api.lumalabs.ai/dream-machine/v1/generations",
    API_KEY_SETTING: "LUMA_API_KEY", // The setting name to fetch from runtime
};
