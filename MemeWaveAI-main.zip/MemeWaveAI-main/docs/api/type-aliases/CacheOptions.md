[@ai16z/eliza v0.1.6-alpha.4](../index.md) / CacheOptions

# Type Alias: CacheOptions

> **CacheOptions**: `object`

## Type declaration

### expires?

> `optional` **expires**: `number`

## Defined in

[packages/core/src/types.ts:992](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L992)
