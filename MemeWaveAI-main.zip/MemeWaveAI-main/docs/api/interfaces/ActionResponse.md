[@ai16z/eliza v0.1.6-alpha.4](../index.md) / ActionResponse

# Interface: ActionResponse

## Properties

### like

> **like**: `boolean`

#### Defined in

[packages/core/src/types.ts:1231](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1231)

***

### retweet

> **retweet**: `boolean`

#### Defined in

[packages/core/src/types.ts:1232](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1232)

***

### quote?

> `optional` **quote**: `boolean`

#### Defined in

[packages/core/src/types.ts:1233](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1233)

***

### reply?

> `optional` **reply**: `boolean`

#### Defined in

[packages/core/src/types.ts:1234](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1234)
