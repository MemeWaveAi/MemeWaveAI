[@ai16z/eliza v0.1.6-alpha.4](../index.md) / LoggingLevel

# Enumeration: LoggingLevel

## Enumeration Members

### DEBUG

> **DEBUG**: `"debug"`

#### Defined in

[packages/core/src/types.ts:1220](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1220)

***

### VERBOSE

> **VERBOSE**: `"verbose"`

#### Defined in

[packages/core/src/types.ts:1221](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1221)

***

### NONE

> **NONE**: `"none"`

#### Defined in

[packages/core/src/types.ts:1222](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L1222)
