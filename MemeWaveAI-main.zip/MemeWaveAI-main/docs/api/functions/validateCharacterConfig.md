[@ai16z/eliza v0.1.6-alpha.4](../index.md) / validateCharacterConfig

# Function: validateCharacterConfig()

> **validateCharacterConfig**(`json`): [`CharacterConfig`](../type-aliases/CharacterConfig.md)

Validation function

## Parameters

• **json**: `unknown`

## Returns

[`CharacterConfig`](../type-aliases/CharacterConfig.md)

## Defined in

[packages/core/src/environment.ts:138](https://github.com/ai16z/eliza/blob/main/packages/core/src/environment.ts#L138)
