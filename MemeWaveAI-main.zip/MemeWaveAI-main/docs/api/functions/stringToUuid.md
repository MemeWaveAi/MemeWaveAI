[@ai16z/eliza v0.1.6-alpha.4](../index.md) / stringToUuid

# Function: stringToUuid()

> **stringToUuid**(`target`): [`UUID`](../type-aliases/UUID.md)

## Parameters

• **target**: `string` \| `number`

## Returns

[`UUID`](../type-aliases/UUID.md)

## Defined in

[packages/core/src/uuid.ts:4](https://github.com/ai16z/eliza/blob/main/packages/core/src/uuid.ts#L4)
