[@ai16z/eliza v0.1.6-alpha.4](../index.md) / parseBooleanFromText

# Function: parseBooleanFromText()

> **parseBooleanFromText**(`text`): `boolean`

## Parameters

• **text**: `string`

## Returns

`boolean`

## Defined in

[packages/core/src/parsing.ts:37](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L37)
