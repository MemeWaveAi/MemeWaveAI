[@ai16z/eliza v0.1.6-alpha.4](../index.md) / generateObjectArray

# Function: generateObjectArray()

> **generateObjectArray**(`__namedParameters`): `Promise`\<`any`[]\>

## Parameters

• **\_\_namedParameters**

• **\_\_namedParameters.runtime**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

• **\_\_namedParameters.context**: `string`

• **\_\_namedParameters.modelClass**: `string`

## Returns

`Promise`\<`any`[]\>

## Defined in

[packages/core/src/generation.ts:836](https://github.com/ai16z/eliza/blob/main/packages/core/src/generation.ts#L836)
