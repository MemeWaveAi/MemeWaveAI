[@ai16z/eliza v0.1.6-alpha.4](../index.md) / elizaLogger

# Variable: elizaLogger

> `const` **elizaLogger**: `ElizaLogger`

## Defined in

[packages/core/src/logger.ts:267](https://github.com/ai16z/eliza/blob/main/packages/core/src/logger.ts#L267)
