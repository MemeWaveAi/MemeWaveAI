[@ai16z/eliza v0.1.6-alpha.4](../index.md) / envSchema

# Variable: envSchema

> `const` **envSchema**: `any`

TODO: TO COMPLETE

## Defined in

[packages/core/src/environment.ts:5](https://github.com/ai16z/eliza/blob/main/packages/core/src/environment.ts#L5)
