[@ai16z/eliza v0.1.6-alpha.4](../index.md) / stringArrayFooter

# Variable: stringArrayFooter

> `const` **stringArrayFooter**: "Respond with a JSON array containing the values in a JSON block formatted for markdown with this structure:\n\`\`\`json\n\[\n  'value',\n  'value'\n\]\n\`\`\`\n\nYour response must include the JSON block."

## Defined in

[packages/core/src/parsing.ts:42](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L42)
