[@ai16z/eliza v0.1.6-alpha.4](../index.md) / settings

# Variable: settings

> `const` **settings**: `Settings`

Initialize settings based on environment

## Defined in

[packages/core/src/settings.ts:126](https://github.com/ai16z/eliza/blob/main/packages/core/src/settings.ts#L126)
