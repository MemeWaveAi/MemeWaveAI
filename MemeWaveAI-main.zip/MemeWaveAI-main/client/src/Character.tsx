export default function Character() {
    return (
        <div className="min-h-screen w-full flex flex-col items-center justify-center p-4">
            <p className="text-lg text-gray-600">WIP</p>
        </div>
    );
}
